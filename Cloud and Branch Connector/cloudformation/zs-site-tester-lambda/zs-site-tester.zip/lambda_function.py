import requests
import random
import os

def lambda_handler(event, context):
    cert_path = 'zscalerroot.pem'
    sites = os.environ.get('SITES', '').split(',')
    
    for site in sites:
        try:
            response = requests.get(site.strip(), verify=cert_path)
            print(f"Request to {site} succeeded with status code {response.status_code}")
        except requests.exceptions.RequestException as e:
            print(f"Request to {site} failed: {str(e)}")

    return "Web requests completed"
