const puppeteer = require("puppeteer-core");
const chromium = require("@sparticuz/chromium");
const fs = require('fs');
const useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.6045.105 Safari/537.36'

exports.handler = async (event, context) => {
  let browser = null;

  try {

    const pemPath = 'zscalerroot.pem';
    const pemData = fs.readFileSync(pemPath);

    browser = await puppeteer.launch({
      args: [
        ...chromium.args,
        '--ignore-certificate-errors',
        '--allow-insecure-localhost',
        `--ignore-certificate-errors-spki-list=${pemData.toString('base64')}`,
      ],
      defaultViewport: chromium.defaultViewport,
      executablePath: await chromium.executablePath(),
      headless: chromium.headless,
      ignoreHTTPSErrors: true,
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.6045.105 Safari/537.36',
    });

    const page = await browser.newPage();  
    await page.setUserAgent(useragent)
    await page.goto('http://securitypreview.zscaler.com');
    await page.keyboard.press('Enter');
    await page.waitForTimeout(65000);

    const threatPreventionResult = await page.evaluate(() =>
    document.querySelector('#threatPreventionResult').innerHTML
    );

  console.log('Threat Prevention Result:', threatPreventionResult);

  const dataProtectionResult = await page.evaluate(() =>
    document.querySelector('#dataProtectionResult').innerHTML
  );

  console.log('Data Protection Result:', dataProtectionResult);

  return {
    statusCode: 200,
    body: JSON.stringify({
      threatPreventionResult,
      dataProtectionResult,
    }),
  };
  } catch (error) {
    console.error('An error occurred:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'An error occurred' }),
    };
  } finally {
    // Close the browser
    if (browser !== null) {
      await browser.close();
    }
  }
};