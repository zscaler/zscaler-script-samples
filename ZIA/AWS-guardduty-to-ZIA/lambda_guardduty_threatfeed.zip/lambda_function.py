import boto3
import requests
import time
import json
import os


def lambda_handler(event, context):
    def get_secret(secret_name):
        print(f"Retrieving secret '{secret_name}' from AWS Secrets Manager...")
        client = boto3.client('secretsmanager')
        try:
            response = client.get_secret_value(SecretId=secret_name)
            secret = json.loads(response['SecretString'])
            print(f"    Successfully retrieved secret '{secret_name}' from AWS Secrets Manager.")
            return secret
        except Exception as e:
            print(f"Error retrieving secret '{secret_name}': {e}")
            raise e

    def get_guardduty_findings():
        print("Connecting to AWS GuardDuty...")
        guardduty_client = boto3.client('guardduty')

        detectors_response = guardduty_client.list_detectors()
        detector_ids = detectors_response.get('DetectorIds', [])

        if not detector_ids:
            raise Exception("Failed to read GuardDuty info. Please check if the service is activated")

        detector_id = detector_ids[0]
        print(f"    Found GuardDuty detector ID: {detector_id}")

        findings = []
        response = guardduty_client.list_findings(DetectorId=detector_id)
        finding_ids = response.get('FindingIds', [])

        if finding_ids:
            details_response = guardduty_client.get_findings(
                DetectorId=detector_id,
                FindingIds=finding_ids
            )
            findings = details_response.get('Findings', [])

        print(f"    Retrieved {len(findings)} findings from GuardDuty.")
        return findings

    def extract_threat_indicators(findings):
        print("    Extracting threat indicators from findings...")
        threat_indicators = {
            'fqdn': set(),
            'ip': set()
        }

        for finding in findings:
            service = finding.get('Service', {})

            remote_ip_details = service.get('Action', {}).get('AwsApiCallAction', {}).get('RemoteIpDetails', {})
            ip_address = remote_ip_details.get('IpAddressV4')
            if ip_address:
                threat_indicators['ip'].add(ip_address)

            if 'ThreatIntelIndicators' in service:
                for indicator in service['ThreatIntelIndicators']:
                    if indicator['Type'] == 'DOMAIN':
                        threat_indicators['fqdn'].add(indicator['Value'])
                    elif indicator['Type'] == 'IPV4':
                        threat_indicators['ip'].add(indicator['Value'])

        print(f"    Extracted {len(threat_indicators['fqdn'])} FQDNs and {len(threat_indicators['ip'])} IPs.")
        return threat_indicators

    def obfuscate_api_key(zscaler_api_key):
        seed = zscaler_api_key
        now = int(time.time() * 1000)
        n = str(now)[-6:]
        r = str(int(n) >> 1).zfill(6)
        key = ""
        for i in range(0, len(str(n)), 1):
            key += seed[int(str(n)[i])]
        for j in range(0, len(str(r)), 1):
            key += seed[int(str(r)[j]) + 2]
        return key

    def zscaler_authenticate(zscaler_api_base_url, zscaler_username, zscaler_password, zscaler_api_key):
        print("Connecting to Zscaler...")
        login_url = f"{zscaler_api_base_url}/authenticatedSession"
        headers = {
            "Content-Type": "application/json",
            "cache-control": "no-cache"
        }
        now = int(time.time() * 1000)
        obfuscated_key = obfuscate_api_key(zscaler_api_key)
        payload = {
            "username": zscaler_username,
            "password": zscaler_password,
            "apiKey": obfuscated_key,
            "timestamp": now
        }

        response = requests.post(login_url, json=payload, headers=headers)
        time.sleep(1)
        response.raise_for_status()

        jsession_id = response.cookies.get('JSESSIONID')
        if not jsession_id:
            raise Exception("Failed to retrieve JSESSIONID from Zscaler API")

        return jsession_id

    def get_existing_destination_groups(zscaler_api_base_url, session_token):
        url = f"{zscaler_api_base_url}/ipDestinationGroups"
        headers = {
            'Content-Type': 'application/json',
            'Cookie': f'JSESSIONID={session_token}'
        }
        response = requests.get(url, headers=headers)
        time.sleep(1)
        response.raise_for_status()
        groups = response.json()
        for group in groups:
            if group['type'] in ['DSTN_FQDN', 'DSTN_IP'] and group['name'] in ['GuardDuty Imported FQDNs',
                                                                               'GuardDuty Imported IPs']:
                print(f"    Found Destination Group - Name: {group['name']}, ID: {group['id']}")
        return groups

    def get_existing_firewall_rules(zscaler_api_base_url, session_token):
        url = f"{zscaler_api_base_url}/firewallFilteringRules"
        headers = {
            'Content-Type': 'application/json',
            'Cookie': f'JSESSIONID={session_token}'
        }
        response = requests.get(url, headers=headers)
        time.sleep(1)
        response.raise_for_status()
        rules = response.json()
        for rule in rules:
            if rule['name'] == 'GuardDuty Filter':
                print(f"    Found Firewall Rule - Name: {rule['name']}, ID: {rule['id']}")
        return rules

    def update_zscaler_policy(zscaler_api_base_url, session_token, fqdn_list, ip_list):
        print("    Updating Zscaler policies...")
        headers = {
            'Content-Type': 'application/json',
            'Cookie': f'JSESSIONID={session_token}'
        }

        # Get existing firewall rules and destination groups
        existing_rules = get_existing_firewall_rules(zscaler_api_base_url, session_token)
        existing_groups = get_existing_destination_groups(zscaler_api_base_url, session_token)
        fqdn_group_id = None
        ip_group_id = None
        rule_id = None

        for group in existing_groups:
            if group['type'] == 'DSTN_FQDN' and group['name'] == 'GuardDuty Imported FQDNs':
                fqdn_group_id = group['id']
            if group['type'] == 'DSTN_IP' and group['name'] == 'GuardDuty Imported IPs':
                ip_group_id = group['id']

        for rule in existing_rules:
            if rule['name'] == 'GuardDuty Filter':
                rule_id = rule['id']

        current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())

        # Create or update the FQDN Destination Group
        if fqdn_list:
            method_type = 'PUT' if fqdn_group_id else 'POST'
            print(f"    Creating/Updating Destination Group(s) using {method_type} method...")
            fqdn_url = f"{zscaler_api_base_url}/ipDestinationGroups/{fqdn_group_id}" if fqdn_group_id else f"{zscaler_api_base_url}/ipDestinationGroups"
            fqdn_payload = {
                "name": "GuardDuty Imported FQDNs",
                "type": "DSTN_FQDN",
                "addresses": fqdn_list,
                "description": f"Imported FQDNs from AWS GuardDuty, last updated on {current_time}"
            }
            method = requests.put if fqdn_group_id else requests.post
            response = method(fqdn_url, json=fqdn_payload, headers=headers)
            time.sleep(1)
            response.raise_for_status()

            # If POST was used, refresh the groups to get the new ID
            if not fqdn_group_id:
                print("    Refreshing destination group IDs after FQDN Destination Group creation...")
                existing_groups = get_existing_destination_groups(zscaler_api_base_url, session_token)
                for group in existing_groups:
                    if group['type'] == 'DSTN_FQDN' and group['name'] == 'GuardDuty Imported FQDNs':
                        fqdn_group_id = group['id']
                        break

        # Create or update the IP Destination Group
        if ip_list:
            method_type = 'PUT' if ip_group_id else 'POST'
            print(f"    Creating/Updating Destination Group(s) using {method_type} method...")
            ip_url = f"{zscaler_api_base_url}/ipDestinationGroups/{ip_group_id}" if ip_group_id else f"{zscaler_api_base_url}/ipDestinationGroups"
            ip_payload = {
                "name": "GuardDuty Imported IPs",
                "type": "DSTN_IP",
                "addresses": ip_list,
                "description": f"Imported IPs from AWS GuardDuty, last updated on {current_time}"
            }
            method = requests.put if ip_group_id else requests.post
            response = method(ip_url, json=ip_payload, headers=headers)
            time.sleep(1)
            response.raise_for_status()

            # If POST was used, refresh the groups to get the new ID
            if not ip_group_id:
                print("    Refreshing destination group IDs after IP Destination Group creation...")
                existing_groups = get_existing_destination_groups(zscaler_api_base_url, session_token)
                for group in existing_groups:
                    if group['type'] == 'DSTN_IP' and group['name'] == 'GuardDuty Imported IPs':
                        ip_group_id = group['id']
                        break

        # Create or update the firewall policy
        dest_ip_groups = []
        if ip_group_id:
            dest_ip_groups.append({"id": ip_group_id, "name": "GuardDuty Imported IPs"})
        if fqdn_group_id:
            dest_ip_groups.append({"id": fqdn_group_id, "name": "GuardDuty Imported FQDNs"})

        if not rule_id:
            print("    Creating/Updating Firewall Rule using POST method...")
            fw_url = f"{zscaler_api_base_url}/firewallFilteringRules"
            rule_payload = {
                "accessControl": "READ_WRITE",
                "enableFullLogging": True,
                "name": "GuardDuty Filter",
                "order": 1,
                "rank": 7,
                "action": "BLOCK_DROP",
                "state": "ENABLED",
                "destIpGroups": dest_ip_groups
            }
            response = requests.post(fw_url, json=rule_payload, headers=headers)
            time.sleep(1)
            response.raise_for_status()

        else:
            print(f"    Creating/Updating Firewall Rule using PUT method...")
            fw_url = f"{zscaler_api_base_url}/firewallFilteringRules/{rule_id}"
            rule_payload = {
                "accessControl": "READ_WRITE",
                "enableFullLogging": True,
                "name": "GuardDuty Filter",
                "order": 1,
                "rank": 7,
                "action": "BLOCK_DROP",
                "state": "ENABLED",
                "destIpGroups": dest_ip_groups
            }
            response = requests.put(fw_url, json=rule_payload, headers=headers)
            time.sleep(1)
            response.raise_for_status()

    # Activate Changes
    def activateChanges(session_token):
        url = f"{zscaler_api_base_url}/status/activate"
        headers = {
            'Content-Type': 'application/json',
            'Cookie': f'JSESSIONID={session_token}'
        }
        print("    Activating changes...", end=" ")
        activation_status = requests.post(url, headers=headers)
        time.sleep(1)
        try:
            status = activation_status.json().get('status', 'UNKNOWN')
            print(f"{status}")
            if status != "ACTIVE":
                raise Exception(f"    Activation failed with status: {status}")
        except ValueError:
            print("    Failed to parse the activation status response as JSON.")
            raise Exception("    Activation failed due to a parsing error.")
        return activation_status
    try:
        findings = get_guardduty_findings()
        threat_indicators = extract_threat_indicators(findings)
        fqdn_list = list(threat_indicators['fqdn'])
        ip_list = list(threat_indicators['ip'])

        # Retrieve Zscaler credentials from AWS Secrets Manager
        secret_name = os.getenv('ZSCALER_SECRET_NAME', 'ZscalerCredentials')
        secret = get_secret(secret_name)

        zscaler_api_base_url = secret.get('zscaler_api_base_url')
        zscaler_username = secret.get('zscaler_username')
        zscaler_password = secret.get('zscaler_password')
        zscaler_api_key = secret.get('zscaler_api_key')

        session_token = zscaler_authenticate(zscaler_api_base_url, zscaler_username, zscaler_password, zscaler_api_key)
        update_zscaler_policy(zscaler_api_base_url, session_token, fqdn_list, ip_list)

        activateChanges(session_token)
        print("Script completed successfully.")
        return {
            "statusCode": 200,
            "body": "Zscaler policies updated successfully"
        }
    except Exception as e:
        print(f"Script failed with error: {e}")
        return {
            "statusCode": 500,
            "body": f"Script failed with error: {e}"
        }